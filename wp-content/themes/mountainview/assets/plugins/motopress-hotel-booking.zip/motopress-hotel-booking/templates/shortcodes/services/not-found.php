<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="mphb-not-found">
	<?php _e( 'No services matched criteria.', 'motopress-hotel-booking' ); ?>
</p>