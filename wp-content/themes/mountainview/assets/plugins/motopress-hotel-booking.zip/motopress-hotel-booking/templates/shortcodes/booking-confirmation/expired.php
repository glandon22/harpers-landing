<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php _e( 'Your booking request is expired. Please start a new booking request.', 'motopress-hotel-booking' ); ?>
</p>